package com.hcl.payload;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JwtResponse {

	private String token;
	private String type = "Bearer";
	private int id;
	private String firstname;
	private String lastname;
	private String username;
	private String contactno;
	private String age;
	private String gender;
	private String role;

	public JwtResponse(String token, int id, String firstname, String lastname, String username, String contactno,
			String age, String gender, String role) {
		super();
		this.token = token;
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.contactno = contactno;
		this.age = age;
		this.gender = gender;
		this.role = role;
	}

}

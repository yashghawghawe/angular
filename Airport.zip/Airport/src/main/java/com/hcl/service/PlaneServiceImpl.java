package com.hcl.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.PlaneDao;
import com.hcl.model.Plane;

@Service
@Transactional
public class PlaneServiceImpl implements PlaneService {

    @Autowired
    private PlaneDao planeDao;

    @Override
    public List<Plane> getAllPlanes() {
        return planeDao.getAllPlanes();
    }

    @Override
    public Optional<Plane> findPlaneById(Integer planeID) {
        return planeDao.findPlaneById(planeID);
    }

    @Override
    public void updatePlane(Plane plane) {
        planeDao.updatePlane(plane);
    }

	@Override
	public void deletePlane(Plane plane) {
		planeDao.deletePlane(plane);
		
	}

}

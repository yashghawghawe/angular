package com.hcl.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.HangarDao;
import com.hcl.model.Hangar;

@Service
@Transactional
public class HangarServiceImpl implements HangarService {
    
    @Autowired
    private HangarDao hangarDao;

    @Override
    public List<Hangar> getALLHangars() {
        return hangarDao.getALLHangars();
    }

    @Override
    public Optional<Hangar> findHangarById(Integer hangarId) {
        return hangarDao.findHangarById(hangarId);
    }

    @Override
    public void updateHangar(Hangar hangar) {
      hangarDao.updateHangar(hangar);
    }

	@Override
	public void deleteHangar(Hangar hangar) {
		hangarDao.deleteHangar(hangar);
		
	}

}

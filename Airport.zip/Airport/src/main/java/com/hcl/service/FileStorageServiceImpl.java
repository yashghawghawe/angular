package com.hcl.service;

import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.hcl.model.FileInfo;
import com.hcl.repository.FileDBRepository;

@Service
public class FileStorageServiceImpl implements FileStorageService {

	@Autowired
	private FileDBRepository repository;
	
	@Override
	public FileInfo store(MultipartFile file) throws Exception {
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		FileInfo FileDB = new FileInfo(fileName, file.getContentType(), file.getBytes());

	    return repository.save(FileDB);
	}

	@Override
	public FileInfo getfile(String id) {
		return repository.findById(id).get();
	}

	@Override
	public Stream<FileInfo> getAllFiles() {
		return repository.findAll().stream();
	}

	@Override
	public void deletefile(String name) {
		 repository.deleteFileByName(name);
		
	}

}

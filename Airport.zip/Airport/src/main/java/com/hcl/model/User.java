/**
 * 
 */
package com.hcl.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author yash.ghawghawe
 *
 */
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	private String firstname;

	private String lastname;

	private String age;

	private String gender;

	private String contactNo;

	private String username;

	private String password;
	@Column(name = "user_role", updatable = false, columnDefinition = "VARCHAR(1) NOT NULL COMMENT 'A = Admin , M = Manager'")
	private String userRole;

	public User(String username, String password, String userRole) {
		super();
		this.username = username;
		this.password = password;
		this.userRole = userRole;
	}

	public User(String username, String password) {
		this.username = username;
		this.password = password;
	}

}

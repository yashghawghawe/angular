package com.hcl.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

import com.hcl.LoginSecurityConfig;

public class DelegatingFilterProxy extends AbstractSecurityWebApplicationInitializer {

    public DelegatingFilterProxy(){
        super(LoginSecurityConfig.class);
    }

}

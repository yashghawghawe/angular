package com.hcl.security;

import java.util.Arrays;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hcl.model.User;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class CustomUserDetails implements UserDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String firstname;
	private String lastname;
	private String username;
	private String contactno;
	private String gender;
	private String age;

	@JsonIgnore
	private String password;
	private User user;

	private GrantedAuthority authorities;

	public CustomUserDetails(int id, String firstname, String lastname, String username, String contactno,
			String gender, String age, String password, GrantedAuthority authorities) {
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.contactno = contactno;
		this.age = age;
		this.gender = gender;
		this.password = password;
		this.authorities = authorities;
	}

	public CustomUserDetails(User user) {
		this.user = user;
	}

	public static CustomUserDetails build(User user) {
		SimpleGrantedAuthority grantedAuthority = new SimpleGrantedAuthority(user.getUserRole());

		return new CustomUserDetails(user.getId(), user.getFirstname(), user.getLastname(), user.getUsername(),
				user.getContactNo(), user.getGender(), user.getAge(), user.getPassword(), grantedAuthority);
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		SimpleGrantedAuthority grantedAuthority = new SimpleGrantedAuthority(this.user.getUserRole());
		return Arrays.asList(grantedAuthority);
	}

	@Override
	public String getPassword() {
		return this.user.getPassword();
	}

	@Override
	public String getUsername() {
		return this.user.getUsername();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

}

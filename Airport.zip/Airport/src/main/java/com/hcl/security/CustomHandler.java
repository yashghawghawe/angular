package com.hcl.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.hcl.model.User;

public class CustomHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
            Authentication auth)
            throws IOException, ServletException {
        CustomUserDetails customUserDetails =  (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        User user= customUserDetails.getUser();
       
            if (user.getUserRole().equalsIgnoreCase("A")) {
                response.sendRedirect(request.getContextPath() + "/adminHome");
            } else {
                response.sendRedirect(request.getContextPath() + "/managerHome");
            }
    }

}

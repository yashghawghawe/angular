/**
 * 
 */
package com.hcl.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.User;
import com.hcl.service.RegisterService;

/**
 * @author yash.ghawghawe
 *
 */
@Controller
@CrossOrigin(origins = "http://localhost:4200")
public class RegisterController {

    @Autowired
    private RegisterService registerService;

    @GetMapping("RegisterUser")
    public ModelAndView showAdminRegPage(@ModelAttribute("user") User user) {
        return new ModelAndView("Register");
    }

    //    @RequestMapping(value = "/SaveUser", consumes = MediaType.APPLICATION_JSON_VALUE)
    //    public Register showAdminRegPage(@RequestBody @Valid Register register) {
    //        return registerService.saveUser(register);
    //    }

    @PostMapping("SaveUser")
    public ModelAndView registeAdmin(@ModelAttribute("user") @Valid User user, BindingResult result) {
        if (result.hasErrors()) {
            return new ModelAndView("Register");
        }
        registerService.saveUser(user);
        return new ModelAndView("SuccessAdmin");
    }

}

package com.hcl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.Hangar;
import com.hcl.model.Plane;
import com.hcl.service.HangarService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/admin")
public class HangarController {

    @Autowired
    private HangarService hangarService;

    @GetMapping(value = "/getAllHangars", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('A')")
    public List<Hangar> getALLHangars() {
        return hangarService.getALLHangars();

    }

    @GetMapping(value = "/gethangarById/{hangarId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Optional<Hangar> findHangarById(@PathVariable(name = "hangarId") Integer hangarId) {
        return hangarService.findHangarById(hangarId);

    }

    @PostMapping(value = "/updateHangar", consumes = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('A')")
    public void updatePlaneDetails(@RequestBody Hangar hangar) {
        hangarService.updateHangar(hangar);

    }
    
    @GetMapping(value = "/updatePageHangar")
    public ModelAndView ShowUpdatePage(@ModelAttribute("hangar") Hangar hangar){
      return new ModelAndView("hangar/UpdateHangar");
        
    }
    
    @PostMapping(value = "/deleteHangar", consumes = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('A')")
    public void deleteHangar(@RequestBody Hangar hangar){
    	if (hangar != null) {
			hangarService.deleteHangar(hangar);
		}
    }

}

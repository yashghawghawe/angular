package com.hcl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.Plane;
import com.hcl.service.PlaneService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/admin")
public class PlaneController {

	@Autowired
	private PlaneService planeService;

	@GetMapping(value = "/getAllPlanes", produces = MediaType.APPLICATION_JSON_VALUE)
	@PreAuthorize("hasRole('A')")
	public List<Plane> getAllPlanes() {
		return planeService.getAllPlanes();
	}

	@GetMapping(value = "/getPlaneById/{planeID}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Optional<Plane> getPlaneById(@PathVariable(name = "planeID") Integer planeID) {
		return planeService.findPlaneById(planeID);
	}

	@PostMapping(value = "/updatePlane", consumes = MediaType.APPLICATION_JSON_VALUE)
	@PreAuthorize("hasRole('A')")
	public void updatePlaneDetails(@RequestBody Plane plane) {
		planeService.updatePlane(plane);
	}

	@GetMapping(value = "/updatePagePlane")
	public ModelAndView ShowUpdatePage(@ModelAttribute("plane") Plane plane) {
		return new ModelAndView("plane/UpdatePlane");

	}

	@PostMapping(value = "/deletePlane", consumes = MediaType.APPLICATION_JSON_VALUE)
	@PreAuthorize("hasRole('A')")
	public void deletePlane(@RequestBody Plane plane) {
		if (plane != null) {
			planeService.deletePlane(plane);
		}
	}

}

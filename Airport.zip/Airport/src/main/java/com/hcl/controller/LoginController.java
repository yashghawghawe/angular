/**
 * 
 */
package com.hcl.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author yash.ghawghawe
 *
 */

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class LoginController {

    @GetMapping("/home")
    public ModelAndView showIndexPage() {
        return new ModelAndView("index");
    }

    @RequestMapping("/LoginUser")
    public ModelAndView showLoginPageAdmin(@RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout) {
        if (error != null) {
            return new ModelAndView("Login", "error", "Invalid login Credentials");
        } else if (logout != null) {
            return new ModelAndView("Login", "message", "Logged Out Successfully");
        }
        return new ModelAndView("Login");
    }

    //    @RequestMapping( value = "/LoginAdmin",consumes =MediaType.APPLICATION_JSON_VALUE)
    //    public Login showLoginPageAdmin(@RequestBody @Valid Login login) {
    //        return loginService.saveData(login);
    //    }

    @GetMapping("/adminHome")
    public ModelAndView showAdminWorkPage() {
        //loginService.saveData(login);
        return new ModelAndView("AdminHome");
    }

    @GetMapping("/403")
    public ModelAndView showAccesssDeniedPage() {
        return new ModelAndView("access_denied", "msg", "You dont have permission to access this page!");
    }
    //    
    //    @PostMapping(value = "/LoginManager" , consumes =MediaType.APPLICATION_JSON_VALUE )
    //    public Login showLoginPageManager(@RequestBody @Valid Login login) {
    //        return loginService.saveData(login);
    //    }

    @GetMapping("/managerHome")
    public ModelAndView showManagerWorkPage() {
        return new ModelAndView("ManagerHome");
    }

}

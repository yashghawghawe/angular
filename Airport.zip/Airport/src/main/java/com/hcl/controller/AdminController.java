/**
 * 
 */
package com.hcl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.model.Hangar;
import com.hcl.model.Pilot;
import com.hcl.model.Plane;
import com.hcl.model.User;
import com.hcl.service.AdminService;

/**
 * @author yash.ghawghawe
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;

	@GetMapping(value = "/ViewManagers", produces = MediaType.APPLICATION_JSON_VALUE) // ViewManagers
	public List<User> showManagers() {
		return adminService.getAllManagers();
	}

	@DeleteMapping("/DeleteUser/{id}")
	public ResponseEntity<String> deleteManager(@PathVariable("id") Integer id){
		String message = "";
		if (id != null) {
			adminService.deleteManager(id);
		}
		message = "Manager Deleted Successfully";
		return ResponseEntity.ok(new String(message));
	}

	@GetMapping("Plane")
	public ModelAndView showPlane(@ModelAttribute("plane") Plane plane) {
		return new ModelAndView("plane/Plane");
	}

	@GetMapping("Pilot")
	public ModelAndView showPilot(@ModelAttribute("pilot") Pilot pilot) {
		return new ModelAndView("pilot/Pilot");
	}

	@GetMapping("Hangar")
	public ModelAndView showHangar(@ModelAttribute("hangar") Hangar hangar) {
		return new ModelAndView("hangar/Hangar");
	}

	@PostMapping(value = "/AddPlane", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Plane addPlane(@RequestBody Plane plane) {
		return adminService.addPlane(plane);
	}

	@PostMapping(value = "/AddPilot", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Pilot addPilot(@RequestBody Pilot pilot) {
		return adminService.addPilot(pilot);
	}

	@PostMapping(value = "/Addhangar", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Hangar addHangar(@RequestBody Hangar hangar) {
		return adminService.addHangar(hangar);
	}

}

package com.hcl.constants;

public enum ERole {
	
	ROLE_ADMIN,
	ROLE_MANAGER

}

package com.hcl.exceptions;

public class FileUploadExceptionsHandler {

}

package com.hcl.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.hcl.model.Pilot;

@CrossOrigin(origins = "http://localhost:4200")
public interface PilotRepository extends JpaRepository<Pilot, Integer>{

	@Transactional
	@Modifying
	@Query("update Pilot p set p.companyID =?1,p.email=?2 where p.pilotName =?3")
	void updatePilot(String companyID,String email,String pilotName);

}

package com.hcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.hcl.model.Hangar;

@CrossOrigin(origins = "http://localhost:4200")
public interface HangarRepository extends JpaRepository<Hangar, Integer> {

	@Modifying
	@Query("update Hangar h set h.hangarName = ?1 ,h.hangarStatus =?2 where h.hangarNumber =?3 ")
	void updateHangar(String hangarName, String hangarStatus, String hangarNumber);

}

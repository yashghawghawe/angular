package com.hcl.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Hangar;
import com.hcl.model.Pilot;
import com.hcl.model.Plane;
import com.hcl.model.User;
import com.hcl.repository.HangarRepository;
import com.hcl.repository.PilotRepository;
import com.hcl.repository.PlaneRepository;
import com.hcl.repository.UserRepository;

@Repository
public class AdminDaoImpl implements AdminDao {
    
    @Autowired
    private PlaneRepository planeRepo;
    
    @Autowired
    private PilotRepository pilotRepo;
    
    @Autowired
    private HangarRepository hangarRepo;
    
    @Autowired
    private UserRepository userRepo;

    @Override
    public Plane addPlane(Plane plane) {
        return planeRepo.save(plane);
    }

    @Override
    public Pilot addPilot(Pilot pilot) {
        return pilotRepo.save(pilot);
    }

    @Override
    public Hangar addHanager(Hangar hangar) {
        return hangarRepo.save(hangar);
    }

    @Override
    public List<User> getAllManagers() {
        return userRepo.getAllManagers();
    }

	@Override
	public void deleteManager(Integer id) {
		userRepo.deleteById(id);
		
	}

}

package com.hcl.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Pilot;
import com.hcl.repository.PilotRepository;

@Repository
public class PilotDaoImpl implements PilotDao {
    
    @Autowired
    private PilotRepository pilotRepo;

    @Override
    public List<Pilot> getAllPilots() {
        return pilotRepo.findAll();
    }

    @Override
    public Optional<Pilot> findPilotById(Integer planeID) {
        return pilotRepo.findById(planeID);
    }

    @Override
    public void updatePilot(Pilot pilot) {
       pilotRepo.updatePilot(pilot.getCompanyID(),pilot.getEmail(),pilot.getPilotName());
    }

	@Override
	public void deletePilot(Pilot pilot) {
		pilotRepo.delete(pilot);
		
	}

}

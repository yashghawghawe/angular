package com.hcl.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Hangar;
import com.hcl.repository.HangarRepository;

@Repository
public class HangarDaoImpl implements HangarDao {

	@Autowired
	private HangarRepository hangarRepo;

	@Override
	public List<Hangar> getALLHangars() {
		return hangarRepo.findAll();
	}

	@Override
	public Optional<Hangar> findHangarById(Integer hangarId) {
		return hangarRepo.findById(hangarId);
	}

	@Override
	public void updateHangar(Hangar hangar) {
		hangarRepo.updateHangar(hangar.getHangarName(), hangar.getHangarStatus(), hangar.getHangarNumber());
	}

	@Override
	public void deleteHangar(Hangar hangar) {
		hangarRepo.delete(hangar);

	}

}

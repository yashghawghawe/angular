package com.hcl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.hcl.repository.UserRepository;
import com.hcl.security.AuthEntryPointJwt;
import com.hcl.security.AuthTokenFilter;
import com.hcl.security.CustomHandler;
import com.hcl.security.service.UserDetailServiceImpl;

@EnableWebSecurity
@EnableJpaRepositories(basePackageClasses = UserRepository.class)
@Configuration
public class LoginSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	private AuthEntryPointJwt unauthorizedHandler;

    @Bean
    public UserDetailsService userDeatilsService(){
        return new UserDetailServiceImpl();
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(11);
    }
    
    @Bean
	public AuthTokenFilter authenticationJwtTokenFilter() {
		return new AuthTokenFilter();
	}
    
    @Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

    @Bean
    public DaoAuthenticationProvider authProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDeatilsService());
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        //        auth.jdbcAuthentication().dataSource(getDataSource())
        //                .usersByUsernameQuery("select username,password from register where username=?")
        //                .authoritiesByUsernameQuery("select user_role from register where username=?");
        auth.authenticationProvider(authProvider());
    }

    @Override
    public void configure(HttpSecurity httpSecurity) throws Exception {
//        httpSecurity.csrf().disable();
//        httpSecurity.authorizeRequests()
//                .antMatchers("/adminHome").hasAnyAuthority("A")
//                .antMatchers("/managerHome").hasAnyAuthority("M")
//                .and()
//                .formLogin().loginPage("/LoginUser")
//                .successHandler(new CustomHandler())
//                .failureUrl("/LoginUser?error")
//                .and().logout().permitAll()
//                .logoutSuccessUrl("/LoginUser?logout")
//                .and().exceptionHandling()
//                .accessDeniedPage("/403");
        
        httpSecurity.cors().and().csrf().disable()
		.exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
		.authorizeRequests()
		.antMatchers("/api/auth/**").permitAll()
		.antMatchers("/admin/**").permitAll()
		.anyRequest().authenticated();
		
        httpSecurity.addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);

    }

    //    private DriverManagerDataSource getDataSource() {
    //        DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
    //        driverManagerDataSource.setDriverClassName("com.mysql.jdbc.Driver");
    //        driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/airport");
    //        driverManagerDataSource.setUsername("root");
    //        driverManagerDataSource.setPassword("root");
    //        return driverManagerDataSource;
    //    }

}

export class Pilot {
    pilotName: string;
    companyID: string
    email: string;
}
export class Hangar {
    hangarId?: number;
    hangarNumber: string;
    hangarName: string;
    hangarStatus: string;
}
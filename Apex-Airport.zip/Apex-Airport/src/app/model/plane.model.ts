export class Plane {
    planeName: string;
    ownerName: string;
    planeType: string;
}